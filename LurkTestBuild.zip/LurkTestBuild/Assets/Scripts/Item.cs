﻿using UnityEngine;
using System.Collections;

public class Item : MonoBehaviour
{
	public Sprite sprite;
}
