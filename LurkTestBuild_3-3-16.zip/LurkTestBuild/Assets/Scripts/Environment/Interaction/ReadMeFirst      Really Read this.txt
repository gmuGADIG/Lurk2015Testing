the interactable script is an abstract class that is extended by interaction and conversation

conversation does not rely on interaction to work

use the conversation prefab in the convo diplay field in the conversation script

use the interaction prefab in the display field in the interaction script

the script interact is depricated - do not use it

i will update this if there is more information that is need for proper use