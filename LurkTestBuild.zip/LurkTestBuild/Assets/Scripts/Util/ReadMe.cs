﻿using UnityEngine;
using System.Collections;

//add a readme to your prefabs
[AddComponentMenu("Utility/Read Me")]
public class ReadMe : MonoBehaviour {

	public string text;

}
